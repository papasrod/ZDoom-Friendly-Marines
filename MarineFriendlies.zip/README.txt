Global Friendly Marines
-This mod utilizes the use of the simple decorate code making it compatible with ZDoom sourceports that don't support Zscript such as ZDoom 2.8.1, Zandronum and more.

(Copied from my Forum post)
- The purpose and aim of this mod is to create a flexible and global friendly
allied helpers that can aid the player wherever it is needed.

- This mod will give the player a new item called "MarineSpawnerPickup"
- The spawner will spawn three friendly ally marines

- The three ally marines :

- "PMarine" - Shoots in a three-burst fire. They do little damage at
enemies.

- "PMarineSG" - Shotgun marine, short-ranged, spreadshot marine.

- "PMarinePlasma" - Plasma marine. Deals heavy, cell-packed plasmaballs
against enemies.

- Tested and works on GZDoom, LZDoom Zandronum, ZDoom 2.8.1 

- If there are any concerns or questions about my mod please leave a comment, any feedback is appreciated! :)

Mod Author: papasrod
